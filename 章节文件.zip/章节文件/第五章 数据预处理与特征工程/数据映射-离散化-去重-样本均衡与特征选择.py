'''
读取’data.xlsx'数据集，其中表格字段信息具体如下：
自变量28个，分别用x1-x27表示，其中x1为日期序号；x3、x4、x10、x11为状态变量，只取两个值：0或1；
剩余的自变量均为连续型取值变量。
因变量1个，用y表示，取值为0或4001
任务如下：
（1）对累计变量做离散化处理，离散区间为 [-1,0,当日最大值*0.25,当日最大值*0.5,当日最大值*0.75,当日最大值]。
    同时对每个离散区间依次用0、1、2、3、4来表示。如果整个变量只取一个值，则不用做离散化。
（2）对故障标签值进行映射操作，即0→0，4001→1。
（3）经过前面的两步，数据集中会有不少重复记录，删掉重复的记录。
（4）经过前面三步得到的数据集，我们作为训练集。训练集中故障标签为1的记录，应该是少数的（故障类），
    而为0的记录是占大多数的，存在类样本不均衡的问题，需要对样本进行均衡处理。
（5）在第（4）步的基础上，作特征选择（特征重要度方法），并对比梯度提升决策树、逻辑回归和支持向量机回归模型的分类效果
'''
def return_values():
    import pandas as pd
    import numpy as np
    
    '''
    1.读取数据
    '''
    A=pd.read_excel('data.xlsx')
    
    '''
    2.因变量映射处理，并覆盖原来的因变量
    '''
    A['y']=A['y'].map({0:0,4001:1})
    
    
    '''
    3.累计变量离散化处理，先定义一个函数，然后调用函数依次对每个变量进行处理,覆盖原来的变量
    '''
    def num_cut(A,field):
        if sum(A[field].values)!=0:
            # 计算当日最大值
            max_val = A[field].max()
            # 定义离散区间
            bins = [-1, 0, max_val * 0.25, max_val * 0.5, max_val * 0.75, max_val]
            r=pd.cut(A[field],bins=bins, labels=[0,1,2,3,4], include_lowest=True)   #请填写完整
            # 转换为整数类型
            r = r.astype(int)
        else:
            r=A[field].values
        return r
    
    A['x2']=num_cut(A,'x2')
    A['x5']=num_cut(A,'x5')
    A['x6']=num_cut(A,'x5')
    A['x7']=num_cut(A,'x7')
    A['x8']=num_cut(A,'x8')
    A['x9']=num_cut(A,'x9')
    A['x12']=num_cut(A,'x12')
    A['x13']=num_cut(A,'x13')
    A['x14']=num_cut(A,'x14')
    A['x15']=num_cut(A,'x15')
    A['x16']=num_cut(A,'x16')
    A['x17']=num_cut(A,'x17')
    A['x18']=num_cut(A,'x18')
    A['x19']=num_cut(A,'x19')
    A['x20']=num_cut(A,'x20')
    A['x21']=num_cut(A,'x21')
    A['x22']=num_cut(A,'x22')
    A['x23']=num_cut(A,'x23')
    A['x24']=num_cut(A,'x24')
    A['x25']=num_cut(A,'x25')
    A['x26']=num_cut(A,'x26')
    A['x27']=num_cut(A,'x27')
    
    A=A.drop_duplicates()  
    
    '''
    4.物理方法进行均衡处理，就是直接对类别少的类数据，重复复制，也可以通过其他方法进行处理
    '''
    A_1=A.iloc[A.iloc[:,-1].values==1,:]
    n=int(len(A_1))
    for i in range(n):
      A_1=pd.concat([A_1, A_1], axis = 0)
      
    A_0=A.iloc[A.iloc[:,-1].values==0,:]
    A=pd.concat([A_1, A_0], axis = 0)
    
    '''
    5.因变量和自变量定义
    '''
    Y=A.iloc[:,-1]
    X=A.iloc[:,1:-1]
    
    '''
    6.训练集和测试集的划分
    '''
    from sklearn.model_selection import train_test_split
    x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, 
    random_state=4)
    
    '''
    7.特征重要度方法识别重要特征，可以尝试其他方法，获取重要特征
    '''
    from sklearn.ensemble import GradientBoostingClassifier # 新版本方法
    model = GradientBoostingClassifier(random_state=0)  # 建立梯度增强分类模型对象
    model.fit(x_train,y_train)
    rv=model.score(x_train,y_train)
    y_pre=model.predict(x_test)
    te=y_test.values-y_pre
    r=len(te[te==0])/len(te)
    res=pd.DataFrame({'y_test':y_test.values,'y_pre':y_pre})
    f=model.feature_importances_
    f=np.round(f,2)
    
    '''
    8.获取重要特征列index序号，所谓重要特征是指重要度大于0的特征
    '''
    importance_index = [i for i, val in enumerate(f) if val > 0]
    #确保至少有一个特征被选中
    if not importance_index:
        importance_index = list(range(len(f)))  # 若所有重要度为0，则使用全部特征
    
    '''
    9.基于重要特征进行模型检验
    '''
    model.fit(x_train.iloc[:,importance_index],y_train)
    rv1=model.score(x_train.iloc[:,importance_index],y_train)
    y_pre=model.predict(x_test.iloc[:,importance_index])
    te=y_test.values-y_pre
    r1=len(te[te==0])/len(te)
    
    from sklearn.linear_model import LogisticRegression as LR
    lr = LR()   #创建逻辑回归模型类
    lr.fit(x_train.iloc[:,importance_index],y_train) #训练数据
    rv2=lr.score(x_train.iloc[:,importance_index],y_train)
    y_pre=lr.predict(x_test.iloc[:,importance_index])
    te=y_test.values-y_pre
    r2=len(te[te==0])/len(te)
    
    from sklearn import svm
    clf = svm.SVC(kernel='rbf')  
    clf.fit(x_train.iloc[:,importance_index],y_train) 
    rv3=clf.score(x_train.iloc[:,importance_index],y_train)
    y_pre=clf.predict(x_test.iloc[:,importance_index])
    te=y_test.values-y_pre
    r3=len(te[te==0])/len(te)
    '''
    评估指标：特征选择后，梯度提升决策树、逻辑回归和支持向量机回归模型的模型准确率和测试准确率
    '''
    return(rv1,r1,rv2,r2,rv3,r3)
