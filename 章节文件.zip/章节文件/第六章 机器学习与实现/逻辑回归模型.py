#在上一关基础，对经过缺失值填充、数值变量标准化后的数据集，取前600条记录作为训练数据，后90条记录作为测试数据
#构逻辑回归模型，返回计算结果模型准确率rv和预测准确率r
def return_values():
    import numpy as np
    import pandas as pd
    from sklearn.linear_model import LogisticRegression as LR
    X1=np.load('X1.npy') #经过缺失值填充、数值变量标准化后的数据集，numpy数组690*15
    Y=np.load('Y.npy')   #因变量，numpy数组，690个元素

    #前600训练
    x1 = X1[:600,:]
    y1 = Y[:600]
    #后90测试
    x2 = X1[600:,:]     
    y2 = Y[600:]

    lr = LR()  
    lr.fit(x1,y1) 
    rv=lr.score(x2,y2)
    R=lr.predict(x2)

    Z=R==y2
    r=len(Z[Z==True])/len(Z)
    
    return(rv,r)
