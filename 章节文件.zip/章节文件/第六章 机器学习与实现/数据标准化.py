#在上一关的基础上，对自变量X中的数值变量（x1~x6）作均值-方差标准化处理
# 需要注意的是x7~x15名义变量不需要作标准化处理
# 返回结果X1，数据结构为数组形式
# X1中含有标准化后的x1~x6和未标准化的x7~x15
def return_values():
    import numpy as np
    import pandas as pd
    from sklearn.preprocessing import StandardScaler

    X=np.load('X.npy')
    X = pd.DataFrame(X)

    x = X.iloc[:,:6]
    y = X.iloc[:,6:-1]
    scaler = StandardScaler()
    scaler.fit(x)
    x=scaler.transform(x)
    x = pd.DataFrame(x)

    X1 = pd.concat([x,y],axis = 1).values
    return X1
