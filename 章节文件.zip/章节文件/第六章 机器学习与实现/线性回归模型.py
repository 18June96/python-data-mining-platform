#在发电场中电力输出（PE）与AT（温度）、V（压力）、AP（湿度）、RH（压强）有关，
# 相关测试数据见“发电场数据.xlsx”文件，请完成以下任务：
# 1)求出PE与AT、V、AP、RH之间的线性回归关系式系数向量,用列表b表示，其元素依次为常数项、AT回归系数、V回归系数、AP回归系数、RH回归系数。
# 2)求出回归方程的拟合优度（判定系数），用变量r表示
# 3)今有某次测试数据AT=28.4、V=50.6、AP=1011.9、RH=80.54，试利用构建的线性回归模型预测其PE值
def return_values():
    import pandas as pd
    from sklearn.linear_model import LinearRegression as LR
    data=pd.read_excel('发电场数据.xlsx')
    x=data.iloc[:,0:4].values    #自变量数据
    y=data.iloc[:,4].values      #因变量数据

    #创建线性回归对象
    lr=LR()
    #对数据进行拟合
    lr.fit(x,y)
    #2)
    c=lr.coef_    #系数
    c_b=lr.intercept_
    b = [c_b]+list(c)
    r=lr.score(x,y)
    #3)
    da = [[28.4,50.6,1011.9,80.54]]
    PE=lr.predict(da)
    return(b,r,PE)
