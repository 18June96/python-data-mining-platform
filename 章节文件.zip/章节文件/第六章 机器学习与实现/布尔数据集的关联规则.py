#针对以下布尔数据集(已用一个“test12.xlsx”表格来存取，直接读取即可，字段名称为A、B、C，“#”号非表格数据):
#   A    B    C
#   1    1    0
#   0    1    1
#   1    0    0
#   1    1    1
#   1    1    1
#   1    0    0
#   1    1    1
#   0    1    1
#   1    0    0
#   1    1    1
#   1    1    0
#   1    1    1
#   1    1    0
##请编程计算规则“A->B”和“A,B->C”的支持度和置信度，分别用sp1和co1,sp2和co2来表示
def return_values():
    import pandas as pd
    data=pd.read_excel('test12.xlsx')
    I1=data['A'].values==1
    I2=data['B'].values==1
    I3=data['C'].values==1
    #A->B
    count_AB = sum(I1 & I2)  #AB
    count_A = sum(I1)
    sp1 = count_AB/len(data)
    co1 = count_AB/count_A

    #A,B->C
    count_ABC = sum(I1 & I2 & I3)  #ABC
    sp2 = count_ABC/len(data)
    co2 = count_ABC/count_AB

    return (sp1,co1,sp2,co2)