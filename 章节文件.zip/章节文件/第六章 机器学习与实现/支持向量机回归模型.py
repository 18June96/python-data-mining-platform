# -*- coding: utf-8 -*-
#基于上一关的数据集，构建支持向量机回归模型（采用线性核函数），返回计算结果模型的拟合优度r，
#并针对测试数据AT=28.4、V=50.6、AP=1011.9、RH=80.54，预测其PE值。
def return_values():
    import pandas as pd  
    import numpy as np
    from sklearn import svm
    data=pd.read_excel('发电场数据.xlsx')  
    x=data.iloc[:,0:4].values  
    y=data.iloc[:,4].values 
    x1 = np.array([[28.4,50.6,1011.9,80.54]])

    clf = svm.SVR(kernel='linear')
    clf.fit(x,y)
    r=clf.score(x,y)
    PE=clf.predict(x1)

    return(r,PE)
    