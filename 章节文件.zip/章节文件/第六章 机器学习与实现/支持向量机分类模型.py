#在上一关基础，对经过缺失值填充、数值变量标准化后的数据集，取前600条记录作为训练数据，后90条记录作为测试数据
#构建支持向量机模型，返回计算结果模型准确率rv和预测准确率r
def return_values():
    import numpy as np
    from sklearn import svm
    X1=np.load('X1.npy') #经过缺失值填充、数值变量标准化后的数据集，numpy数组690*15
    Y=np.load('Y.npy')   #因变量，numpy数组，690个元素
    #前600训练
    x1 = X1[:600,:]
    y1 = Y[:600]
    #后90测试
    x2 = X1[600:,:]     
    y2 = Y[600:]

    clf = svm.SVC(kernel='rbf')  
    clf.fit(x1, y1) 
    rv=clf.score(x2, y2);
    R=clf.predict(x1)

    Z=R-y1
    r=len(Z[Z==0])/len(Z)
