#1.定义一个列表code,编号为1~30
#2.对code，按30个元素一次随机抽样，记为A
#3.返回结果，为序列s，其中index为编号，值为抽样结果
def return_values():
    import random as rm
    import pandas as pd
    code=list(range(1,31))
    s = []
    while len(code):
        index = rm.randint(0,len(code)-1)
        values = code.pop(index)
        s.append(values)
    s = pd.Series(s,index=range(1,31))
    return s