def return_values():
    #1.导入pandas包
    import pandas as pd
    #2.定义列表L
    L=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15]

    #3.把列表L转化为序列S
    S = pd.Series(L)

    #4.针对S实现周期为10的移动求和、求平均值、求最大值、求最小值的计算
    Sum= S.rolling(10).sum()
    mean= S.rolling(10).mean()
    max1= S.rolling(10).max()
    min1= S.rolling(10).min()

    return(L,S,Sum)

