import pandas as pd
import numpy as np
def return_values():
    #1.定义三个字典dict1、dict2和dict3
    dict1={'a':[2,2,'kt',6],'b':[4,6,7,8],'c':[6,5,np.nan,6]}
    dict2={'d':[8,9,10,11],'e':['p',16,10,8]}
    dict3={'a':[1,2],'b':[2,3],'c':[3,4],'d':[4,5],'e':[5,6]}
    #2.将三个字典转化为数据框df1、df2、df3；
    df1 = pd.DataFrame(dict1)
    df2 = pd.DataFrame(dict2)
    df3 = pd.DataFrame(dict3)

    #3.df1和df2进行水平合并，合并后的数据框记为df4；
    df4 = pd.concat([df1,df2],axis=1)

    #4.df3和df4垂直合并，并修改合并后的index为按默认顺序排列,修改合并后的数据框记为df5
    df5 = pd.concat([df3,df4],axis=0)

    return(df4,df5)
