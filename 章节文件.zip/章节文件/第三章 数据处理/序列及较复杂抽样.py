def return_values():
    #定义一个数据框A，index为默认序号（0~39），代表每一位同学
    #数据框A的第0列表示每位同学随机抽签的第1种题型的序号，第1、2、3、4列依次类推
    #知识点，考查random.randint()，随机整数的生成应用
    import random
    import pandas as pd
    t1=[]
    t2=[]
    t3=[]
    t4=[]
    t5=[]
    for i in range(40):
        t1.append(random.randint(1,70))
        t2.append(random.randint(1,80))
        t3.append(random.randint(1,50))
        t4.append(random.randint(1,30))
        t5.append(random.randint(1,20))
    A=pd.DataFrame({'t1':t1,'t2':t2,'t3':t3,'t4':t4,'t5':t5})
    return A    