#本关任务：
#读取地铁站点进出站客流数据表（Data.xlsx），统计计算获得每个站点每个时刻（除去国庆期间）的总进站客流量和总出站客流量，
#用一个数据框来R表示，结果返回R，列名依次为：A1_站点编号、A2_时刻、A3_总进站客流、A4_总出站客流
def return_values():
    import pandas as pd
    import numpy as np
    #读取数据
    df = pd.read_excel('Data.xlsx')
    df = df[(df['日期'] < '2015-10-01') | (df['日期'] > '2015-10-07')]
    station = df.iloc[:,0].unique()
    time = df.iloc[:,2].unique()
    A1 =[]
    A2 =[]
    A3 =[]
    A4 =[]
    for i in range(len(station)):
        d1=df.iloc[df['站点编号'].values==station[i],:]
        for j in range(len(time)):

            A1.append(station[i])
            A2.append(time[j])
            A3.append(df['进站人数'].sum())
            A4.append(df['出站人数'].sum())

    R=pd.DataFrame({'A1_站点编号':A1,'A2_时刻':A2,'A3_总进站客流':A3,'A4_总出站客流':A4}) 
    return(R) 
        
