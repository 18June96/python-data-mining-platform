#序列与数据框
#1.导入pandas包
#2.定义列表L1、L2，元组T1、T2
L1=[1,-2,2.3,'hq']
L2=['kl','ht','as','km']
T1=(1,8,8,9)
T2=(2,4,7,'hp')
#3.构造数据框，默认索引，列名依次为a,b,c,d，返回计算结果A
#4.构造数据框，索引为a,b,c,d,列名为L1,L2,T1,T2，返回计算结果B
def return_values():
    import pandas as pd
    data = {'a':L1,'b':L2,'c':T1,'d':T2}
    A = pd.DataFrame(data)
    data_2 = {'L1':L1,'L2':L2,'T1':T1,'T2':T2}
    B = pd.DataFrame(data_2,index=['a','b','c','d'])
    return(A,B)