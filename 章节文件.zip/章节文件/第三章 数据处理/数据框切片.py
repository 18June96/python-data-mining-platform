#1、导入pdndas包
#2、读取地铁站点进出站客流数据表（Data.xlsx）,字段依次为：
#   站点编号、日期、时刻、进站人数、出站人数
#3、采用索引（iloc）实现的方式，获取135站点
#   10月1日-10月2日早上9-11点3个时刻的进站客流量数据(取所有字段)，记为A
#4、采用列标签（loc)实现方式，获取135站点
#   10月1日-10月2日早上9-11点3个时刻的进站客流量数据（取所有字段）,记为B。
def return_values():
    import pandas as pd
    D=pd.read_excel('Data.xlsx')
    I1=D.iloc[:,0].values==135
    I2=(D.iloc[:,1].values>='2015-10-01') & (D.iloc[:,1].values<='2015-10-02')
    A3 = D['时刻'].values>=9
    A4 = D['时刻'].values<=11

    A=D.iloc[I1 & I2 & A3 & A4,[0,1,2,3]] 

    I1=D['站点编号'].values==135
    I2=(D['日期'].values>='2015-10-01') & (D['日期'].values<'2015-10-03')
    A3 = D['时刻'].values>=9
    A4 = D['时刻'].values<=11

    B=D.loc[I1 & I2 & A3 & A4,:] 
    return(A,B)
