# 逻辑索引、切片方法，groupby 分组计算函数

#请读取地铁站点进出站客流数据表(Data.xlsx)，表结构字段如下：
# 站点编号、日期、时刻、进站人数、出站人数
#完成以下任务：
#1）取出第0列，通过去重的方式获得地铁站点编号列表，记为code
#2）采用数据框中的groupby分组计算函数，统计出每个地铁站点每天的进站人数和出站人数，
#   计算结果采用一个数据框sat_num来表示，其中列标签依次为：站点编号、日期、进站人数和出站人数；
#3）计算出每个站点国庆节期间（10.1~10.7）的进站人数和出站人数，
#   计算结果用一个数据框sat_num2来表示，其中列标签依次为:A1_站点编号、A2_进站人数、A3_出站人数。
def return_values():
    import pandas as pd
    A=pd.read_excel('Data.xlsx')
    dt = A.iloc[:,0]
    code= dt.unique()
    #按站点编号,日期进行分组，分别统计计算进站人数和出站人数，记为B1和B2
    B1=A.groupby(['站点编号','日期'])['进站人数'].sum().reset_index()
    B2=A.groupby(['站点编号','日期'])['出站人数'].sum().reset_index()

    #sat_num结果整理
    sat_num = pd.DataFrame({
        '站点编号': B1['站点编号'],
        '日期': B1['日期'],
        '进站人数': B1['进站人数'],
        '出站人数': B2['出站人数']
    })
    #根据sat_num，筛选国庆期间的数据，记为D
    sat_num['日期'] = pd.to_datetime(sat_num['日期'])
    D = sat_num[sat_num['日期'].astype(str).str.contains('2015-10-0[1-7]')]
    #对D按站点编号进行分组，分别统计计算进站人数和出站人数，记为D1和D2
    D1=D.groupby(['站点编号'])['进站人数'].sum().reset_index()
    D2=D.groupby(['站点编号'])['出站人数'].sum().reset_index()

    #sat_num2结果整理
    sat_num2 = pd.DataFrame({
        'A1_站点编号': D1['站点编号'],
        'A2_进站人数': D1['进站人数'],
        'A3_出站人数': D2['出站人数']
    })
    return(code,sat_num,sat_num2)
