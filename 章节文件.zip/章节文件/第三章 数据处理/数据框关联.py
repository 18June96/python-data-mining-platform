def return_values():
    #1.导入pandas包
    import pandas as pd
    #2.定义两个字典 dict1 和 dict2
    dict1={'code':['A01','A01','A01','A02','A02','A02','A03','A03'],
           'month':['01','02','03','01','02','03','01','02'],
           'price':[10,12,13,15,17,20,10,9]}
    dict2={'code':['A01','A01','A01','A02','A02','A02'],
           'month':['01','02','03','01','02','03'], 
           'vol':[10000,10110,20000,10002,12000,21000]}
    #3.将两个字典转化为数据框；
    df1=pd.DataFrame(dict1)
    df2=pd.DataFrame(dict2)       
              
    #4.对两个数据框完成内连接、左连接、右连接；
    df_inner = pd.merge(df1,df2,how='inner',on=['code','month'])
    df_left = pd.merge(df1,df2,how='left',on=['code','month'])
    df_right = pd.merge(df1,df2,how='right',on=['code','month'])
    return(df_inner,df_left,df_right)

