#1.导入pandas包
#2.用read_excel()函数读取“data.xlsx"表，用数据框read表示
#3.提取600000.SH代码交易数据，并按交易日期从小到大进行排序,记为data
#4.对整个数据框read,按代码、交易日期从小到大进行排序
def return_values():
    import pandas as pd
    read = pd.read_excel('data.xlsx')
    read = pd.DataFrame(read)
    data = read.iloc[read['代码'].values=='600000.SH',:].sort_values('交易日期',axis=0)

    da1 = read.sort_values('代码')
    da2 = da1.sort_values('交易日期')
    return(data,da2)
