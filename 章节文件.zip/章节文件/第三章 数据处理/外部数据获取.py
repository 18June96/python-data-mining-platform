#1.导入pandas包
#2.read_excel()函数读取“一、车次上车人数统计表.xlsx”中的数据，用一个数据框df1来存储
#3.通过read_table()函数可以读取"txt1.txt"文件中的数据（不带表头），用一个数据框df2来表示
#4.通过read_csv()函数读取用分块读取的方式读取“data.csv”文件，每次读取20000行，并输出每次读取的数据集行数
#5.输出格式为“第n次读取数据规模为：20000 /n (20000, 列数)”
#在函数中编写程序
import pandas as pd
def return_values():
    df1 = pd.read_excel("一、车次上车人数统计表.xlsx")
    df2 = pd.read_table("txt1.txt")
    reader = pd.read_csv("data.csv",chunksize=20000)
    k=0;
    names = locals()#设置全局变量
    for i in reader:
        k+=1
        names['A%s'%k]=pd.DataFrame(i)#创建A1~Ak个变量，分别保存各分块
        print('第'+str(k)+'次读取数据规模为：',len(i))
        print(i.shape)
